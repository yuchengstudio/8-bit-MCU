#ifndef __ERROR_H
#define __ERROR_H

#define ERROR_PTR -1

#endif
