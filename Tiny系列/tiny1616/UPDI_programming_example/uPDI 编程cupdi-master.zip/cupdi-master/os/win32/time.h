#ifndef __WIN32_TIME_H
#define __WIN32_TIME_H

void msleep(int ms);

#endif
