#include <windows.h>
#include "time.h"

//delay millisecond here
void msleep(int ms)
{
    Sleep(ms);
}