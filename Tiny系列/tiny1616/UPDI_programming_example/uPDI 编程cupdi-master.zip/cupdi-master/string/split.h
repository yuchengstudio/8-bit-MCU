#ifndef __STR_SPLIT_H
#define __STR_SPLIT_H

/*
    split the string
    https://stackoverflow.com/questions/9210528/split-string-with-delimiters-in-c
*/
char** str_split(char* a_str, const char a_delim);

#endif
