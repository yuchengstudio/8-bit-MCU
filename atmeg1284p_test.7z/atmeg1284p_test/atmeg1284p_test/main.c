#include <atmel_start.h>
const uint8_t data[] = {1,2,3,4,5,6};
uint8_t i;

int main(void)
{
	unsigned int test;
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	/* Replace with your application code */
	while (1) {
		test = data[i++];
		if (i > 4)
		{
			i=0x00;
		}
	}
}
